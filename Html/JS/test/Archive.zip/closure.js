function createCalculator(initialValue) {
    let value = initialValue;

    const calculator = {
        add(num) {
            value += num;
            return this;
        },
        subtract(num) {
            value -= num;
            return this;
        },
        multiply(num) {
            value *= num;
            return this;
        },
        divide(num) {
            if (num === 0) {
                throw new Error("Cannot divide by zero");
            }
            value /= num;
            return this;
        },
        clear() {
            value = 0;
            return this;
        },
        get() {
            return value;
        }
    };

    return calculator;
}

const calc = createCalculator(10);

console.log(calc.add(5).multiply(2).subtract(4).get())




