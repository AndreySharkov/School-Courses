﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Advertisement_Message
{
    public static class ProductPhrases
    {
        public static string[] Phrases = { "Excellent product.", "Such a great product.", "I always use that product.",
                                       "Best product of its category.", "Exceptional product.", "I can’t live without this product." };

        public static string[] Events = { "Now I feel good.", "I have succeeded with this product.",
                                      "Makes miracles. I am happy of the results!", "I cannot believe but now I feel awesome.",
                                      "Try it yourself, I am very satisfied.", "I feel great!" };

        public static string[] Authors = { "Diana", "Petya", "Stella", "Elena", "Katya", "Iva", "Annie", "Eva" };

        public static string[] Cities = { "Burgas", "Sofia", "Plovdiv", "Varna", "Ruse" };
    }
}
